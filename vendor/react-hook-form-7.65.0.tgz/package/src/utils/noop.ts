export default function noop() {}

