React Hook Form 7.65.0, MIT licensed.
Official source: https://github.com/react-hook-form/react-hook-form/tree/v7.65.0
Commit: 1ebe316f71eb90ca6bf4c55c0881754f2d868ccf
Built locally with Vite 8 / TypeScript 5.9 because npm registry access was unavailable. Original source and license are included. No library source changes.
